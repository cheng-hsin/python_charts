class Snake():#宣告一個貪食蛇類別
    def __init__(self):##初始化建構方法
        self.position = [400,300]#蛇頭初始座標
        self.body = [[400,300],[390,300],[380,300]]#蛇身初始位置
        self.direction = "RIGHT"#蛇頭初始方向
        self.speed = 12

    def changeDir(self, dir):#改變方向
        if dir == "RIGHT" and self.direction != "LEFT":#當要改變的方向為向右而且目前方向不是向左時
            self.direction = dir#改變方向
        if dir == "LEFT" and self.direction != "RIGHT":#當要改變的方向為向左而且目前方向不是向右時
            self.direction = dir#改變方向
        if dir == "UP" and self.direction != "DOWN":#當要改變的方向為向下而且目前方向不是向上時
            self.direction = dir#改變方向
        if dir == "DOWN" and self.direction != "UP":#當要改變的方向為向上而且目前方向不是向下時
            self.direction = dir#改變方向

    def move(self, food):#移動
        if self.direction == "RIGHT":#當蛇頭方向為向右時
            self.position[0] = self.position[0] + 10  #往右移動10像素
        if self.direction == "LEFT":#當蛇頭方向為向右時
            self.position[0] = self.position[0] - 10  #往左移動10像素
        if self.direction == "UP":#當蛇頭方向為向右時
            self.position[1] = self.position[1] - 10  #往上移動10像素
        if self.direction == "DOWN":#當蛇頭方向為向右時
            self.position[1] = self.position[1] + 10  #往下移動10像素

        self.body.insert(0, list(self.position)) #蛇頭會等於下一個前進的位置
        moveresult = [False,False] #兩個食物一開始都沒有被吃到(result都為False)
        
        #判斷蛇頭是否吃到食物，food改寫成兩個個食物
        for i in range(0, len(food)): 
            if self.position == food[i]: #當蛇頭吃到某一個食物
                moveresult[i] = True
            else:
                moveresult[i] = False
        
        if moveresult[0] == True or moveresult[1] == True:#如果蛇頭吃到其中一個食物(蛇身+1)
            return moveresult 
        else: #如果蛇頭沒有吃到任何食物(蛇身-1(利用pop()函式)
            self.body.pop()
            return moveresult
            

    def checkCollision(self):#是否撞牆
        if self.position[0] > 790 or self.position[0] < 0:
            return True  #撞牆了
        elif self.position[1] >590 or self.position[1] < 0:
            return True #撞牆了
        return False  #沒有撞牆

    def getHead(self):#取得蛇頭位置
        return self.position
    def getBody(self):#取得身體list
        return self.body
    def getSpeed(self):
        return self.speed
    def setSpeed(self,speed):
        self.speed = speed
        

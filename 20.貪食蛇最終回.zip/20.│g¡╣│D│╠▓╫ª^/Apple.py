import random
class Apple():#蘋果類別宣告
    def __init__(self):#初始化建構方法
        self.position = [random.randrange(1,80) * 10, random.randrange(1,60) * 10]#隨機座標產生一個蘋果
        self.AppleOnSccreen = True#此變數用來判斷蘋果是否在螢幕上

    def spawnFood(self):#產生一顆新的蘋果
        if self.AppleOnSccreen == False:#當蘋果不在螢幕上時
            self.position = [random.randrange(1,80) * 10, random.randrange(1,60) * 10]##隨機座標產生一個蘋果
            self.AppleOnSccreen = True#產生後，蘋果是否在螢幕上的變數更改為True
        return self.position#回傳蘋果座標
    def setAppleOnScreen(self, isExist):#設定蘋果是否存在於螢幕上，True在, False不在
        self.AppleOnSccreen = isExist

import pygame
import random
import Snake
import Apple
pygame.init()#pygame初始化

screen = pygame.display.set_mode((800,600))

pygame.display.set_caption("貪食蛇")
clock = pygame.time.Clock()

snake = Snake.Snake()
apple = Apple.Apple()

white = (255,255,255)
red = (255,0,0)
gameOver = False
gameRun = True
speed = 24 #速度的初始值
while gameRun: #遊戲主程式
    clock.tick(speed) #時間控制器
    
    for event in pygame.event.get():
        #事件捕抓區
        if event.type == pygame.QUIT:
            gameRun = False
        elif event.type == pygame.KEYDOWN: #按下鍵盤事件
            if event.key == pygame.K_RIGHT:
                snake.changeDir("RIGHT")
            if event.key == pygame.K_LEFT:
                snake.changeDir("LEFT")
            if event.key == pygame.K_UP:
                snake.changeDir("UP")
            if event.key == pygame.K_DOWN:
                snake.changeDir("DOWN")
            if event.key == pygame.K_x:
                print("你按下了X鍵，這時候要加速")
                speed = 36 #設定為36
        elif event.type == pygame.KEYUP:#放開鍵盤事件
            if event.key == pygame.K_x:
                print("你放開了X鍵，這時候要減速")
                speed = 24 #設定為24
        #事件捕抓區的結束

    #繪圖區
    applePosition = apple.spawnFood()
    if(snake.move(applePosition) == 1):
        apple.setAppleOnScreen(False)
    screen.fill((238,83,155))
    
    for pos in snake.getBody(): #getBody會取得蛇的身體(list)
        pygame.draw.rect(screen,(255,255,255),[pos[0],pos[1],10,10],0)
    pygame.draw.rect(screen,(255,255,255),[applePosition[0],applePosition[1],10,10],0)
    
    if snake.checkCollision() == 1: #撞牆了
        #snake = Snake.Snake()
        gameOver = True

    #gameOver 畫面
    while gameOver: #gameOver=True時，畫面會停在這裡
        for event in pygame.event.get():
            if event.type == pygame.QUIT:#在黑畫面裡按下x按鍵
                gameOver = False
                gameRun = False
            elif event.type == pygame.KEYDOWN: #按下任意鍵重新遊戲
                gameOver = False
                snake = Snake.Snake() #重新初始化蛇
                
        img = pygame.image.load('Pygame_logo.png') #取得圖片
        
        screen.fill((0,0,0,))#背景設定為黑色
        screen.blit(img,(300,250))#將圖片放在300,250位置

        fontVar = pygame.font.SysFont("DFKai-SB",48)
        textVar = fontVar.render("Game Over 請按下任意鍵重新",True,(255,255,255),
                                 (0,0,0))
        screen.blit(textVar,(150,150))
        
        pygame.display.update()#更新畫布
    pygame.display.update()
    
pygame.quit()
        
